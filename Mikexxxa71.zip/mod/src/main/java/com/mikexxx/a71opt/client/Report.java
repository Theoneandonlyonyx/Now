package com.mikexxx.a71opt.client;

import com.mikexxx.a71opt.A71Config;
import com.mikexxx.a71opt.A71Optimizer;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.loading.FMLPaths;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Schreibt config/mikexxx_a71opt-bericht.txt und gibt wenige, kurze Hinweise im Chat aus.
 * Es werden nur Messwerte und Befunde gemeldet, es wird nichts automatisch entfernt oder veraendert.
 */
final class Report {

    /** Mods, die selbst RAM "aufraeumen" oder Speicher ueberwachen. Mehrere davon parallel sind selten sinnvoll. */
    private static final String[] MEMORY_MODS = {"lagless", "laglessmod", "memguard", "fastlaunch"};

    /** Bekannte Performance-Mods, nur zur Uebersicht im Bericht. */
    private static final String[] BOOST_MODS = {
            "embeddium", "oculus", "ferritecore", "modernfix", "entityculling", "immediatelyfast",
            "saturn", "krypton", "noisiumed", "lightspeed", "alltheleaks"
    };

    private Report() {
    }

    // ------------------------------------------------------------------ Messwerte

    private static long heapMaxMb() {
        return Runtime.getRuntime().maxMemory() / 1048576L;
    }

    /** Liefert {gesamtMb, verfuegbarMb} aus /proc/meminfo, -1 wenn nicht lesbar. */
    private static long[] deviceMemoryMb() {
        long total = -1L;
        long avail = -1L;
        try {
            for (String line : Files.readAllLines(Paths.get("/proc/meminfo"), StandardCharsets.UTF_8)) {
                if (line.startsWith("MemTotal:")) {
                    total = kbToMb(line);
                } else if (line.startsWith("MemAvailable:")) {
                    avail = kbToMb(line);
                }
            }
        } catch (Throwable ignored) {
            // nicht lesbar: -1 bleibt stehen
        }
        return new long[]{total, avail};
    }

    private static long kbToMb(String line) {
        String digits = line.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) {
            return -1L;
        }
        return Long.parseLong(digits) / 1024L;
    }

    private static List<String> presentFrom(String[] ids) {
        List<String> found = new ArrayList<>();
        ModList mods = ModList.get();
        for (String id : ids) {
            if (mods.isLoaded(id)) {
                found.add(id);
            }
        }
        return found;
    }

    private static String glInfo() {
        try {
            String renderer = GL11.glGetString(GL11.GL_RENDERER);
            String version = GL11.glGetString(GL11.GL_VERSION);
            return renderer + " | " + version;
        } catch (Throwable t) {
            return "nicht lesbar";
        }
    }

    // ------------------------------------------------------------------ Bericht-Datei

    static void writeFile() {
        try {
            Path file = FMLPaths.CONFIGDIR.get().resolve("mikexxx_a71opt-bericht.txt");
            long[] dev = deviceMemoryMb();
            long heap = heapMaxMb();
            List<String> memMods = presentFrom(MEMORY_MODS);
            List<String> boostMods = presentFrom(BOOST_MODS);

            List<String> out = new ArrayList<>();
            out.add("Mikexxx A71 Optimizer - Bericht (wird bei jedem Start neu geschrieben)");
            out.add("");
            out.add("Mods geladen:            " + ModList.get().size());
            out.add("Java:                    " + System.getProperty("java.version"));
            out.add("CPU-Kerne (fuer Java):   " + Runtime.getRuntime().availableProcessors());
            out.add("Heap (max):              " + heap + " MB");
            out.add("Geraete-RAM gesamt:      " + (dev[0] > 0 ? dev[0] + " MB" : "unbekannt"));
            out.add("Geraete-RAM verfuegbar:  " + (dev[1] > 0 ? dev[1] + " MB (beim Start)" : "unbekannt"));
            out.add("Grafik:                  " + glInfo());
            out.add("");
            out.add("Performance-Mods im Pack: " + (boostMods.isEmpty() ? "keine" : String.join(", ", boostMods)));
            out.add("Speicher-/Aufraeum-Mods:  " + (memMods.isEmpty() ? "keine" : String.join(", ", memMods)));
            out.add("");
            out.add("Hinweise:");
            for (String hint : hints(heap, dev, memMods)) {
                out.add(" - " + hint);
            }
            out.add("");
            out.add("Einstellungen dieser Mod: config/mikexxx_a71opt-client.toml");
            Files.write(file, out, StandardCharsets.UTF_8);
        } catch (IOException e) {
            A71Optimizer.LOGGER.warn("[A71] Bericht konnte nicht geschrieben werden", e);
        } catch (Throwable t) {
            A71Optimizer.LOGGER.warn("[A71] Bericht-Fehler", t);
        }
    }

    // ------------------------------------------------------------------ Hinweise

    private static List<String> hints(long heapMb, long[] dev, List<String> memMods) {
        List<String> hints = new ArrayList<>();
        int mods = ModList.get().size();

        if (dev[0] > 0 && heapMb * 100L > dev[0] * 45L) {
            hints.add("Heap " + heapMb + " MB ist viel fuer ein Geraet mit " + dev[0] + " MB RAM. Auf dem Handy ist weniger"
                    + " oft besser, weil Android RAM fuer GPU und Shader braucht. Testweise im Launcher senken.");
        }
        if (memMods.size() >= 2) {
            hints.add("Mehrere Speicher-/Aufraeum-Mods laufen parallel (" + String.join(", ", memMods)
                    + "). Testweise nur einen davon behalten und FPS/Ruckler vergleichen.");
        }
        int cpus = Runtime.getRuntime().availableProcessors();
        if (cpus <= 4) {
            hints.add("Java sieht nur " + cpus + " CPU-Kerne. Dann teilen sich Render, Server, Weltgenerierung und"
                    + " Speicher-Aufraeumen wenige Kerne. Im MJLauncher testweise die Big-Core-Affinitaet ausschalten"
                    + " (falls als Option vorhanden).");
        }
        return hints;
    }

    /** Hoechstens zwei kurze Zeilen beim ersten Betreten einer Welt. */
    static void firstJoinHints(Minecraft mc) {
        if (!A71Config.CHAT_HINTS.get()) {
            return;
        }
        try {
            List<String> hints = hints(heapMaxMb(), deviceMemoryMb(), presentFrom(MEMORY_MODS));
            int shown = 0;
            for (String hint : hints) {
                if (shown >= 2) {
                    break;
                }
                Governor.msg(mc, Governor.YELLOW + "[A71]" + Governor.RESET + " " + hint);
                shown++;
            }
            if (shown > 0) {
                Governor.msg(mc, Governor.GRAY + "Mehr dazu: config/mikexxx_a71opt-bericht.txt (/a71 report)");
            }
        } catch (Throwable t) {
            A71Optimizer.LOGGER.warn("[A71] Hinweise nicht moeglich", t);
        }
    }

    /** Fuer /a71 report: Kennzahlen im Chat, Datei neu schreiben. */
    static void chatSummary(Minecraft mc) {
        writeFile();
        long[] dev = deviceMemoryMb();
        Governor.msg(mc, String.format(Locale.ROOT,
                Governor.GREEN + "[A71]" + Governor.RESET + " %d Mods | Heap max %d MB | Geraet %s | Kerne %d",
                ModList.get().size(), heapMaxMb(),
                dev[0] > 0 ? dev[0] + " MB (frei " + dev[1] + ")" : "?",
                Runtime.getRuntime().availableProcessors()));
        List<String> hints = hints(heapMaxMb(), dev, presentFrom(MEMORY_MODS));
        for (String hint : hints) {
            Governor.msg(mc, Governor.GRAY + " - " + hint);
        }
        Governor.msg(mc, Governor.GRAY + "Bericht: config/mikexxx_a71opt-bericht.txt");
    }
}
