package com.mikexxx.a71opt;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Einstellungen. Datei im Spiel: config/mikexxx_a71opt-client.toml
 */
public final class A71Config {

    public static final ForgeConfigSpec SPEC;

    // allgemein
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.BooleanValue CHAT_HINTS;
    public static final ForgeConfigSpec.BooleanValue SHOW_HUD;

    // A71-Profil
    public static final ForgeConfigSpec.BooleanValue APPLY_PROFILE;
    public static final ForgeConfigSpec.IntValue PROFILE_RENDER_DISTANCE;
    public static final ForgeConfigSpec.IntValue PROFILE_SIMULATION_DISTANCE;
    public static final ForgeConfigSpec.IntValue PROFILE_MAX_FPS;
    public static final ForgeConfigSpec.BooleanValue PROFILE_FAST_GRAPHICS;
    public static final ForgeConfigSpec.BooleanValue PROFILE_FEWER_PARTICLES;
    public static final ForgeConfigSpec.BooleanValue PROFILE_NO_CLOUDS;
    public static final ForgeConfigSpec.BooleanValue PROFILE_NO_ENTITY_SHADOWS;
    public static final ForgeConfigSpec.BooleanValue PROFILE_SHORT_ENTITY_DISTANCE;
    public static final ForgeConfigSpec.BooleanValue PROFILE_LOW_BIOME_BLEND;

    // Notbremse
    public static final ForgeConfigSpec.BooleanValue EMERGENCY;
    public static final ForgeConfigSpec.IntValue EMERGENCY_FPS;
    public static final ForgeConfigSpec.IntValue EMERGENCY_RENDER_DISTANCE;
    public static final ForgeConfigSpec.BooleanValue EMERGENCY_SHADERS_OFF;

    // Spawn-Chunks (integrierter Server)
    public static final ForgeConfigSpec.BooleanValue SHRINK_SPAWN_CHUNKS;
    public static final ForgeConfigSpec.IntValue SPAWN_CHUNK_RADIUS;

    // adaptive Renderdistanz
    public static final ForgeConfigSpec.BooleanValue ADAPTIVE;
    public static final ForgeConfigSpec.IntValue TARGET_FPS;
    public static final ForgeConfigSpec.IntValue MIN_RENDER_DISTANCE;
    public static final ForgeConfigSpec.IntValue MAX_RENDER_DISTANCE;
    public static final ForgeConfigSpec.IntValue JOIN_RENDER_DISTANCE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("allgemein");
        ENABLED = b.comment("Mod komplett ein- oder ausschalten.")
                .define("aktiv", true);
        CHAT_HINTS = b.comment("Kurze Hinweise im Chat beim ersten Betreten einer Welt (z.B. zu wenig RAM).")
                .define("chatHinweise", true);
        SHOW_HUD = b.comment("Kleine Anzeige oben links: FPS, Server-Tickzeit, Renderdistanz, RAM. Im Spiel: /a71 hud")
                .define("hud", true);
        b.pop();

        b.push("profil");
        APPLY_PROFILE = b.comment("A71-Profil beim ersten Start einmalig anwenden.",
                        "Erneut anwenden: /a71 profil  (oder Datei config/mikexxx_a71opt.profil-angewendet loeschen).")
                .define("beimErstenStartAnwenden", true);
        PROFILE_RENDER_DISTANCE = b.comment("Wunsch-Renderdistanz (Obergrenze fuer die Automatik).")
                .defineInRange("renderdistanz", 5, 2, 32);
        PROFILE_SIMULATION_DISTANCE = b.comment("Simulationsdistanz (5 ist das Minimum im Spiel). Weniger = weniger Tick-Last.")
                .defineInRange("simulationsdistanz", 5, 5, 32);
        PROFILE_MAX_FPS = b.comment("Bildraten-Limit (spart Akku und Waerme, vermeidet Throttling).")
                .defineInRange("maxFps", 60, 10, 260);
        PROFILE_FAST_GRAPHICS = b.comment("Grafik auf 'Schnell' (undurchsichtige Blaetter, weniger Ueberzeichnung).")
                .define("grafikSchnell", true);
        PROFILE_FEWER_PARTICLES = b.comment("Partikel auf 'Reduziert'.")
                .define("wenigerPartikel", true);
        PROFILE_NO_CLOUDS = b.comment("Vanilla-Wolken aus.")
                .define("wolkenAus", true);
        PROFILE_NO_ENTITY_SHADOWS = b.comment("Entity-Schatten aus.")
                .define("entitySchattenAus", true);
        PROFILE_SHORT_ENTITY_DISTANCE = b.comment("Entity-Sichtweite auf Minimum (50 Prozent).")
                .define("entitySichtweiteMinimum", true);
        PROFILE_LOW_BIOME_BLEND = b.comment("Biom-Uebergang auf 1 (weniger CPU beim Chunk-Bauen).")
                .define("biomUebergangKlein", true);
        b.pop();

        b.push("notbremse");
        EMERGENCY = b.comment("Wenn das Spiel einfriert (sehr niedrige FPS, Speicher-Aufraeumen frisst die Zeit oder der Heap ist voll),",
                        "wird sofort hart gebremst statt Schritt fuer Schritt.")
                .define("aktiv", true);
        EMERGENCY_FPS = b.comment("Unter diesen FPS (mindestens 6 Sekunden am Stueck) greift die Notbremse.")
                .defineInRange("fps", 6, 1, 30);
        EMERGENCY_RENDER_DISTANCE = b.comment("Renderdistanz, auf die die Notbremse sofort springt (2 = Minimum im Spiel).")
                .defineInRange("renderdistanz", 2, 2, 8);
        EMERGENCY_SHADERS_OFF = b.comment("Shader bei der Notbremse ausschalten (braucht Oculus). Wieder an: /a71 shader on")
                .define("shaderAus", true);
        b.pop();

        b.push("spawn");
        SHRINK_SPAWN_CHUNKS = b.comment("Vanilla haelt rund um den Welt-Spawn dauerhaft ca. 20x20 Chunks geladen und tickend",
                        "(auch wenn du weit weg bist). Das kostet RAM, Tick-Zeit und beim Speichern sehr viel Zeit.",
                        "Hier wird dieser Bereich nach dem Start verkleinert. Betrifft nur die Oberwelt.")
                .define("spawnChunksVerkleinern", true);
        SPAWN_CHUNK_RADIUS = b.comment("Neuer Radius in Chunks (Vanilla = 11). 2 entspricht dem neueren Minecraft-Standard, 0 = gar nicht halten.")
                .defineInRange("spawnChunkRadius", 2, 0, 10);
        b.pop();

        b.push("adaptiv");
        ADAPTIVE = b.comment("Renderdistanz automatisch an FPS und Server-Tickzeit anpassen.",
                        "Beim Betreten einer Welt wird klein gestartet und schrittweise hochgefahren.")
                .define("aktiv", true);
        TARGET_FPS = b.comment("Ziel-FPS. Tipp: so viel FPS, wie du in der Flachwelt hast.",
                        "Unter 75 Prozent davon wird die Renderdistanz gesenkt, ueber 110 Prozent (laenger anhaltend) wieder erhoeht.")
                .defineInRange("zielFps", 24, 10, 120);
        MIN_RENDER_DISTANCE = b.comment("Kleinste Renderdistanz, auf die die Automatik senken darf.")
                .defineInRange("minRenderdistanz", 3, 2, 16);
        MAX_RENDER_DISTANCE = b.comment("Groesste Renderdistanz, auf die die Automatik erhoehen darf.")
                .defineInRange("maxRenderdistanz", 7, 2, 32);
        JOIN_RENDER_DISTANCE = b.comment("Start-Renderdistanz beim Betreten einer Welt (danach schrittweise hoch).")
                .defineInRange("startRenderdistanz", 3, 2, 32);
        b.pop();

        SPEC = b.build();
    }

    private A71Config() {
    }
}
